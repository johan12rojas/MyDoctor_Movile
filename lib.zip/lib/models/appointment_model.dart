class AppointmentModel {
  final String numeroCita;
  final DateTime fechaCita;
  final String hora;
  final String cedulaPaciente;
  final String nombrePaciente;
  final String apellidoPaciente;
  final String observaciones;
  final String tipoCita;
  final String estado;
  final DateTime fechaRegistro;

  AppointmentModel({
    required this.numeroCita,
    required this.fechaCita,
    required this.hora,
    required this.cedulaPaciente,
    required this.nombrePaciente,
    required this.apellidoPaciente,
    required this.observaciones,
    required this.tipoCita,
    required this.estado,
    required this.fechaRegistro,
  });
}

