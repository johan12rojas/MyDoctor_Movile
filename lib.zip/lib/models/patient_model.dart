class PatientModel {
  final String cedula;
  final String nombre;
  final String apellido;
  final String telefono;
  final String email;
  final DateTime fechaNacimiento;
  final String motivoConsulta;
  final String? entidad;
  final String? procedimiento;
  final DateTime? fechaAtencion;
  final String? estadoPago;
  final String? metodoPago;   // 🔹 nuevo campo
  final DateTime? fechaPago;  // 🔹 nuevo campo

  const PatientModel({
    required this.cedula,
    required this.nombre,
    required this.apellido,
    required this.telefono,
    required this.email,
    required this.fechaNacimiento,
    required this.motivoConsulta,
    this.entidad,
    this.procedimiento,
    this.fechaAtencion,
    this.estadoPago,
    this.metodoPago,  // 🔹 nuevo
    this.fechaPago,   // 🔹 nuevo
  });

  factory PatientModel.fromJson(Map<String, dynamic> json) {
    return PatientModel(
      cedula: json['cedula'] ?? '',
      nombre: json['nombre'] ?? '',
      apellido: json['apellido'] ?? '',
      telefono: json['telefono'] ?? '',
      email: json['email'] ?? '',
      fechaNacimiento: DateTime.parse(json['fecha_nacimiento']),
      motivoConsulta: json['motivo_consulta'] ?? '',
      entidad: json['entidad'],
      procedimiento: json['procedimiento'],
      fechaAtencion: json['fecha_atencion'] != null
          ? DateTime.parse(json['fecha_atencion'])
          : null,
      estadoPago: json['estado_pago'],
      metodoPago: json['metodo_pago'], // 🔹 nuevo
      fechaPago: json['fecha_pago'] != null
          ? DateTime.parse(json['fecha_pago'])
          : null, // 🔹 nuevo
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'cedula': cedula,
      'nombre': nombre,
      'apellido': apellido,
      'telefono': telefono,
      'email': email,
      'fecha_nacimiento': fechaNacimiento.toIso8601String(),
      'motivo_consulta': motivoConsulta,
      'entidad': entidad,
      'procedimiento': procedimiento,
      'fecha_atencion': fechaAtencion?.toIso8601String(),
      'estado_pago': estadoPago,
      'metodo_pago': metodoPago, // 🔹 nuevo
      'fecha_pago': fechaPago?.toIso8601String(), // 🔹 nuevo
    };
  }

  PatientModel copyWith({
    String? cedula,
    String? nombre,
    String? apellido,
    String? telefono,
    String? email,
    DateTime? fechaNacimiento,
    String? motivoConsulta,
    String? entidad,
    String? procedimiento,
    DateTime? fechaAtencion,
    String? estadoPago,
    String? metodoPago,   // 🔹 nuevo
    DateTime? fechaPago,  // 🔹 nuevo
  }) {
    return PatientModel(
      cedula: cedula ?? this.cedula,
      nombre: nombre ?? this.nombre,
      apellido: apellido ?? this.apellido,
      telefono: telefono ?? this.telefono,
      email: email ?? this.email,
      fechaNacimiento: fechaNacimiento ?? this.fechaNacimiento,
      motivoConsulta: motivoConsulta ?? this.motivoConsulta,
      entidad: entidad ?? this.entidad,
      procedimiento: procedimiento ?? this.procedimiento,
      fechaAtencion: fechaAtencion ?? this.fechaAtencion,
      estadoPago: estadoPago ?? this.estadoPago,
      metodoPago: metodoPago ?? this.metodoPago, // 🔹 nuevo
      fechaPago: fechaPago ?? this.fechaPago,   // 🔹 nuevo
    );
  }
}

