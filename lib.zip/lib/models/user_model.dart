
//definicion de la clase UserModel que representa a un doctor o usuario del sistema
class UserModel {
  final String cedula;
  final String nombre;
  final String apellido;
  final String email;
  final DateTime fechaNacimiento;
  final String especializacion;
  final String telefono; 
  final String password;

 //constructor de la clase
 //el uso de required hace que todos los campos sean obligatorios al crear una instancia
   UserModel({
    required this.cedula,
    required this.nombre,
    required this.apellido,
    required this.email,
    required this.fechaNacimiento,
    required this.especializacion,
    required this.telefono,
    required this.password,
  });
}

