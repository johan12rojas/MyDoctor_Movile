import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/data_service.dart';
import '../models/patient_model.dart';
import '../widgets/sidebar_menu.dart';
import '../widgets/user_profile_button.dart';


class PagosScreen extends StatefulWidget {
  @override
  State<PagosScreen> createState() => _PagosScreenState();
}

class _PagosScreenState extends State<PagosScreen> {
  final TextEditingController _cedulaController = TextEditingController();
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _procedimientoController = TextEditingController();
  final TextEditingController _valorController = TextEditingController();
  final TextEditingController _entidadController = TextEditingController();
  DateTime? _fechaPago;

  String? _metodoPago; // 🔹 Nuevo campo
  final df = DateFormat('yyyy-MM-dd');

  void _buscarPaciente() {
    final cedula = _cedulaController.text.trim();
    final paciente = DataService.patients.firstWhere(
      (p) => p.cedula == cedula,
      orElse: () => PatientModel(
        cedula: '',
        nombre: '',
        apellido: '',
        telefono: '',
        email: '',
        fechaNacimiento: DateTime.now(),
        motivoConsulta: '',
      ),
    );

    if (paciente.cedula.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Paciente no encontrado')),
      );
      _nombreController.text = '';
    } else {
      _nombreController.text = '${paciente.nombre} ${paciente.apellido}';
    }
  }

  void _registrarPago() {
    if (_cedulaController.text.isEmpty ||
        _procedimientoController.text.isEmpty ||
        _valorController.text.isEmpty ||
        _entidadController.text.isEmpty ||
        _fechaPago == null ||
        _metodoPago == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor completa todos los campos')),
      );
      return;
    }

    final pacienteIndex = DataService.patients.indexWhere(
     (p) => p.cedula == _cedulaController.text.trim(),
    );

    if (pacienteIndex != -1) {
    DataService.patients[pacienteIndex] = DataService.patients[pacienteIndex].copyWith(
      estadoPago: 'Pagado',
      metodoPago: _metodoPago,
      fechaPago: _fechaPago,
    );
   }

    // Aquí puedes guardar el pago en tu servicio o base de datos
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Pago registrado para ${_nombreController.text.isEmpty ? _cedulaController.text : _nombreController.text}',
        ),
      ),
    );

    // Limpia el formulario
    _cedulaController.clear();
    _nombreController.clear();
    _procedimientoController.clear();
    _valorController.clear();
    _entidadController.clear();
    _fechaPago = null;
    _metodoPago = null;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: SidebarMenu(),
      appBar: AppBar(
        title: const Text('Gestión de Pagos', style: TextStyle(color: Colors.black)),
        leading: const UserProfileButton(),
      ),
      body: Row(
        children: [
          // Menú lateral fijo (igual que Home y Citas)
          LayoutBuilder(builder: (context, constraints) {
            if (constraints.maxWidth > 900) {
              return Container(width: 220, child: SidebarMenu());
            }
            return const SizedBox.shrink();
          }),

          // Contenido principal
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Registro de Pagos',
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 20),

                    Card(
                      elevation: 3,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            // Cédula
                            TextFormField(
                              controller: _cedulaController,
                              decoration: InputDecoration(
                                labelText: 'Cédula del paciente',
                                suffixIcon: IconButton(
                                  icon: const Icon(Icons.search),
                                  onPressed: _buscarPaciente,
                                ),
                                border: const OutlineInputBorder(),
                              ),
                            ),
                            const SizedBox(height: 12),

                            // Nombre (solo lectura)
                            TextFormField(
                              controller: _nombreController,
                              readOnly: true,
                              decoration: const InputDecoration(
                                labelText: 'Nombre del paciente',
                                border: OutlineInputBorder(),
                              ),
                            ),
                            const SizedBox(height: 12),

                            // Procedimiento
                            TextFormField(
                              controller: _procedimientoController,
                              decoration: const InputDecoration(
                                labelText: 'Procedimiento',
                                border: OutlineInputBorder(),
                              ),
                            ),
                            const SizedBox(height: 12),

                            // Valor
                            TextFormField(
                              controller: _valorController,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(
                                labelText: 'Valor a pagar',
                                border: OutlineInputBorder(),
                              ),
                            ),
                            const SizedBox(height: 12),

                            // Entidad
                            TextFormField(
                              controller: _entidadController,
                              decoration: const InputDecoration(
                                labelText: 'Entidad',
                                border: OutlineInputBorder(),
                              ),
                            ),
                            const SizedBox(height: 12),

                            // 🔹 Nuevo: Método de pago
                            DropdownButtonFormField<String>(
                              decoration: const InputDecoration(
                                labelText: 'Método de pago',
                                border: OutlineInputBorder(),
                              ),
                              value: _metodoPago,
                              items: const [
                                DropdownMenuItem(
                                    value: 'Efectivo', child: Text('Efectivo')),
                                DropdownMenuItem(
                                    value: 'Transferencia',
                                    child: Text('Transferencia')),
                                DropdownMenuItem(
                                    value: 'Tarjeta', child: Text('Tarjeta')),
                                DropdownMenuItem(
                                    value: 'Otro', child: Text('Otro')),
                              ],
                              onChanged: (value) =>
                                  setState(() => _metodoPago = value),
                            ),
                            const SizedBox(height: 12),

                            // Fecha de pago
                            Row(
                              children: [
                                Expanded(
                                  child: InputDecorator(
                                    decoration: const InputDecoration(
                                      labelText: 'Fecha de pago',
                                      border: OutlineInputBorder(),
                                    ),
                                    child: Text(_fechaPago != null
                                        ? df.format(_fechaPago!)
                                        : 'Selecciona una fecha'),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                ElevatedButton.icon(
                                  icon: const Icon(Icons.calendar_today),
                                  label: const Text('Elegir'),
                                  onPressed: () async {
                                    final DateTime? picked = await showDatePicker(
                                      context: context,
                                      initialDate: DateTime.now(),
                                      firstDate: DateTime(2020),
                                      lastDate: DateTime(2100),
                                    );
                                    if (picked != null) {
                                      setState(() => _fechaPago = picked);
                                    }
                                  },
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),

                            ElevatedButton.icon(
                              icon: const Icon(Icons.save),
                              label: const Text('Registrar Pago'),
                              onPressed: _registrarPago,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
