import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/data_service.dart';
import '../models/patient_model.dart';
import '../widgets/sidebar_menu.dart';
import '../widgets/user_profile_button.dart';
import '../widgets/patient_form_dialog.dart';
import '../services/export_service.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<PatientModel> get patients => DataService.patients;
  List<PatientModel> filteredPatients = [];
  final TextEditingController searchController = TextEditingController();
  final df = DateFormat('yyyy-MM-dd');

  @override
  void initState() {
    super.initState();
    filteredPatients = patients;
  }

  //función de búsqueda: filtra por cualquier campo visible
  void _filterPatients(String query) {
    setState(() {
      if (query.isEmpty) {
        filteredPatients = patients;
      } else {
        final q = query.toLowerCase();
        filteredPatients = patients.where((p) {
          return p.cedula.toLowerCase().contains(q) ||
              p.nombre.toLowerCase().contains(q) ||
              p.apellido.toLowerCase().contains(q) ||
              p.telefono.toLowerCase().contains(q) ||
              p.email.toLowerCase().contains(q) ||
              p.motivoConsulta.toLowerCase().contains(q) ||
              (p.entidad?.toLowerCase().contains(q) ?? false) ||
              (p.estadoPago?.toLowerCase().contains(q) ?? false) ||
              (p.fechaAtencion != null && 
                  DateFormat('yyyy-MM-dd').format(p.fechaAtencion!).contains(q));
        }).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: SidebarMenu(),
      appBar: AppBar(
        title: const Text('My Doctor App', style: TextStyle(color: Colors.black)),
        leading: const UserProfileButton(),
      ),
      body: Row(
        children: [
          LayoutBuilder(builder: (context, constraints) {
            if (constraints.maxWidth > 900) {
              return Container(width: 220, child: SidebarMenu());
            }
            return SizedBox.shrink();
          }),
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('¡Bienvenido ${DataService.usuarioActual?.nombre ?? ''}!',
                      style: TextStyle(fontSize: 24)),
                  SizedBox(height: 12),

                  //Campo de búsqueda actualizado
                  TextField(
                    controller: searchController,
                    decoration: InputDecoration(
                      hintText: 'Buscar paciente por cualquier campo...',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    onChanged: _filterPatients,
                  ),
                  SizedBox(height: 12),

                  Card(
                    child: Padding(
                      padding: EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Lista de Pacientes', style: TextStyle(fontSize: 18)),
                              Row(
                                children: [
                                  ElevatedButton.icon(
                                    onPressed: () async {
                                      final added = await showDialog(
                                        context: context,
                                        builder: (_) => PatientFormDialog(),
                                      );
                                      if (added == true) {
                                        setState(() => filteredPatients = patients);
                                      }
                                    },
                                    icon: Icon(Icons.person_add),
                                    label: Text('Agregar Paciente'),
                                  ),
                                  SizedBox(width: 8),
                                  OutlinedButton.icon(
                                    onPressed: () {
                                      ExportService.exportPatientsToCsv(filteredPatients);
                                    },
                                    icon: Icon(Icons.grid_on),
                                    label: Text('Generar Excel'),
                                  ),
                                  SizedBox(width: 8),
                                  OutlinedButton.icon(
                                    onPressed: () async {
                                      await ExportService.exportPatientsToPdf(filteredPatients);
                                    },
                                    icon: Icon(Icons.picture_as_pdf),
                                    label: Text('Generar Reporte PDF'),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 12),

                          //tabla actualizada con nuevos campos visibles
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: DataTable(
                              columns: [
                                DataColumn(label: Text('Cédula')),
                                DataColumn(label: Text('Nombre')),
                                DataColumn(label: Text('Apellido')),
                                DataColumn(label: Text('Teléfono')),
                                DataColumn(label: Text('Correo')),
                                DataColumn(label: Text('Entidad')),
                                DataColumn(label: Text('Motivo Consulta')),
                                DataColumn(label: Text('Fecha Nac.')),
                                DataColumn(label: Text('Fecha Atención')),
                                DataColumn(label: Text('Estado de Pago')),
                                DataColumn(label: Text('Acciones')),
                              ],
                              rows: filteredPatients.map((p) {
                                return DataRow(cells: [
                                  DataCell(Text(p.cedula)),
                                  DataCell(Text(p.nombre)),
                                  DataCell(Text(p.apellido)),
                                  DataCell(Text(p.telefono)),
                                  DataCell(Text(p.email)),
                                  DataCell(Text(p.entidad ?? 'Sin entidad')),
                                  DataCell(Text(p.motivoConsulta)),
                                  DataCell(Text(df.format(p.fechaNacimiento))),
                                  DataCell(Text(
                                      p.fechaAtencion != null
                                          ? df.format(p.fechaAtencion!)
                                          : '—')),
                                  DataCell(
                                    Text(
                                      (p.estadoPago ?? '').isEmpty
                                             ? 'Pendiente'
                                             : p.estadoPago!.toLowerCase() == 'Pagado'
                                                  ? 'Pagado'
                                                  : p.estadoPago!,
                                      style: TextStyle(
                                        color: (p.estadoPago ?? '').toLowerCase() == 'Pagado'
                                        ? Colors.green
                                        : Colors.red,
                                      fontWeight: FontWeight.bold
                                      ),        
                                    ),
                                  ),




                                  
                                  DataCell(Row(
                                    children: [
                                      IconButton(
                                        icon: Icon(Icons.edit, color: Colors.orange),
                                        onPressed: () async {
                                          final res = await showDialog(
                                            context: context,
                                            builder: (_) => PatientFormDialog(patient: p),
                                          );
                                          if (res == true) {
                                            setState(() => filteredPatients = patients);
                                          }
                                        },
                                      ),
                                      IconButton(
                                        icon: Icon(Icons.delete, color: Colors.red),
                                        onPressed: () {
                                          showDialog(
                                            context: context,
                                            builder: (_) => AlertDialog(
                                              title: Text('Confirmar'),
                                              content: Text('¿Eliminar paciente ${p.nombre} ${p.apellido}?'),
                                              actions: [
                                                TextButton(
                                                  onPressed: () => Navigator.pop(context),
                                                  child: Text('Cancelar'),
                                                ),
                                                ElevatedButton(
                                                  onPressed: () {
                                                    DataService.deletePatient(p.cedula);
                                                    Navigator.pop(context);
                                                    setState(() => filteredPatients = patients);
                                                  },
                                                  child: Text('Eliminar'),
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                      ),
                                    ],
                                  )),
                                ]);
                              }).toList(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

