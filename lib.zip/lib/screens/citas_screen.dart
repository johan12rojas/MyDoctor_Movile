import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/appointment_model.dart';
import '../services/data_service.dart';
import '../widgets/sidebar_menu.dart';
import '../widgets/user_profile_button.dart';
import '../models/patient_model.dart';


class CitasScreen extends StatefulWidget {
  @override
  _CitasScreenState createState() => _CitasScreenState();
}

class _CitasScreenState extends State<CitasScreen> {
  List<AppointmentModel> citasFiltradas = [];
  final TextEditingController searchController = TextEditingController();
  final df = DateFormat('yyyy-MM-dd');

  @override
  void initState() {
    super.initState();
    citasFiltradas = DataService.citas;
  }

  void filtrarCitas(String query) {
    setState(() {
      query = query.toLowerCase();
      citasFiltradas = DataService.citas.where((c) {
        return c.nombrePaciente.toLowerCase().contains(query) ||
            c.apellidoPaciente.toLowerCase().contains(query) ||
            c.cedulaPaciente.toLowerCase().contains(query);
      }).toList();
    });
  }

  Future<void> mostrarFormularioCita({AppointmentModel? cita}) async {
    final numeroCtrl = TextEditingController(text: cita?.numeroCita ?? '');
    final nombreCtrl = TextEditingController(text: cita?.nombrePaciente ?? '');
    final apellidoCtrl = TextEditingController(text: cita?.apellidoPaciente ?? '');
    final cedulaCtrl = TextEditingController(text: cita?.cedulaPaciente ?? '');
    final observacionesCtrl = TextEditingController(text: cita?.observaciones ?? '');
    DateTime? fechaSeleccionada = cita?.fechaCita;
    String? horaSeleccionada = cita?.hora;
    String? tipoSeleccionado = cita?.tipoCita;
    String? estadoSeleccionado = cita?.estado;

    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setModalState) => AlertDialog(
          title: Text(cita == null ? 'Agregar Cita' : 'Editar Cita'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(controller: numeroCtrl, decoration: InputDecoration(labelText: 'Número de Cita')),
                TextField(controller: nombreCtrl, decoration: InputDecoration(labelText: 'Nombre del Paciente')),
                TextField(controller: apellidoCtrl, decoration: InputDecoration(labelText: 'Apellido del Paciente')),
                TextField(controller: cedulaCtrl, decoration: InputDecoration(labelText: 'Cédula')),
                SizedBox(height: 10),
                Text('Fecha:', style: TextStyle(fontWeight: FontWeight.bold)),
                ElevatedButton(
                  onPressed: () async {
                    final pickedDate = await showDatePicker(
                      context: context,
                      initialDate: fechaSeleccionada ?? DateTime.now(),
                      firstDate: DateTime.now(),
                      lastDate: DateTime(2030),
                    );
                    if (pickedDate != null) {
                      setModalState(() => fechaSeleccionada = pickedDate);
                    }
                  },
                  child: Text(
                    fechaSeleccionada != null
                        ? df.format(fechaSeleccionada!)
                        : 'Seleccionar fecha',
                  ),
                ),
                SizedBox(height: 10),
                Text('Hora:', style: TextStyle(fontWeight: FontWeight.bold)),
                DropdownButtonFormField<String>(
                  value: horaSeleccionada,
                  hint: Text('Seleccionar hora'),
                  items: [
                    ...List.generate(5, (i) => '0${7 + i}:00'),
                    ...['14:00', '15:00', '16:00', '17:00']
                  ].map((h) => DropdownMenuItem(value: h, child: Text(h))).toList(),
                  onChanged: (val) => setModalState(() => horaSeleccionada = val),
                ),
                SizedBox(height: 10),
                TextField(controller: observacionesCtrl, decoration: InputDecoration(labelText: 'Observaciones')),
                SizedBox(height: 10),
                Text('Tipo de Cita:', style: TextStyle(fontWeight: FontWeight.bold)),
                Wrap(
                  spacing: 8,
                  children: [
                    ChoiceChip(
                      label: Text('Consulta'),
                      selected: tipoSeleccionado == 'Consulta',
                      onSelected: (val) => setModalState(() => tipoSeleccionado = 'Consulta'),
                    ),
                    ChoiceChip(
                      label: Text('Procedimiento'),
                      selected: tipoSeleccionado == 'Procedimiento',
                      onSelected: (val) => setModalState(() => tipoSeleccionado = 'Procedimiento'),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Text('Estado:', style: TextStyle(fontWeight: FontWeight.bold)),
                Wrap(
                  spacing: 8,
                  children: [
                    ChoiceChip(
                      label: Text('Pendiente'),
                      selected: estadoSeleccionado == 'Pendiente',
                      onSelected: (val) => setModalState(() => estadoSeleccionado = 'Pendiente'),
                    ),
                    ChoiceChip(
                      label: Text('Finalizado'),
                      selected: estadoSeleccionado == 'Finalizado',
                      onSelected: (val) => setModalState(() => estadoSeleccionado = 'Finalizado'),
                    ),
                    ChoiceChip(
                      label: Text('Cancelado'),
                      selected: estadoSeleccionado == 'Cancelado',
                      onSelected: (val) => setModalState(() => estadoSeleccionado = 'Cancelado'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancelar')),
            ElevatedButton(
              onPressed: () {
                if (numeroCtrl.text.isEmpty ||
                    nombreCtrl.text.isEmpty ||
                    apellidoCtrl.text.isEmpty ||
                    cedulaCtrl.text.isEmpty ||
                    fechaSeleccionada == null ||
                    horaSeleccionada == null ||
                    tipoSeleccionado == null ||
                    estadoSeleccionado == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Por favor completa todos los campos')),
                  );
                  return;
                }

                final existeConflicto = DataService.citas.any((c) =>
                    c.hora == horaSeleccionada &&
                    c.fechaCita == fechaSeleccionada &&
                    c.numeroCita != cita?.numeroCita);
                if (existeConflicto) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Esa hora ya está ocupada, elige otro momento')),
                  );
                  return;
                }

                final nuevaCita = AppointmentModel(
                  numeroCita: numeroCtrl.text,
                  fechaCita: fechaSeleccionada!,
                  hora: horaSeleccionada!,
                  cedulaPaciente: cedulaCtrl.text,
                  nombrePaciente: nombreCtrl.text,
                  apellidoPaciente: apellidoCtrl.text,
                  observaciones: observacionesCtrl.text,
                  tipoCita: tipoSeleccionado!,
                  estado: estadoSeleccionado!,
                  fechaRegistro: cita?.fechaRegistro ?? DateTime.now(),
                );

                if (cita == null) {
                  DataService.addAppointment(nuevaCita);
                } else {
                  DataService.updateAppointment(nuevaCita);
                }

                final existePaciente = DataService.patients.any(
                     (p) => p.cedula == cedulaCtrl.text.trim(),
                );

                if (!existePaciente) {

                  final nuevoPaciente = PatientModel(
                    cedula: cedulaCtrl.text.trim(),
                    nombre: nombreCtrl.text.trim(),
                    apellido: apellidoCtrl.text.trim(),
                    telefono: '',
                    email: '',
                    fechaNacimiento: DateTime.now(),
                    motivoConsulta: observacionesCtrl.text.trim(),
                    entidad: '',
                    procedimiento: '',
                    fechaAtencion: DateTime.now(),
                    estadoPago: '',

                  );

                  DataService.patients.add(nuevoPaciente);

                }

                setState(() => citasFiltradas = DataService.citas);
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(cita == null ? 'Cita agregada correctamente' : 'Cita actualizada correctamente')),
                );
              },
              child: Text(cita == null ? 'Guardar' : 'Actualizar'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade50, //Fondo 
      drawer: SidebarMenu(),
      appBar: AppBar(
        backgroundColor: Colors.white, // Barra superior blanca
        foregroundColor: Colors.black,
        elevation: 0,
        title: Text('Citas Médicas'),
        leading: UserProfileButton(),
      ),
      body: Row(
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              if (constraints.maxWidth > 900) {
                return Container(width: 220, child: SidebarMenu());
              }
              return SizedBox.shrink();
            },
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Gestión de Citas', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                      ElevatedButton.icon(
                        icon: Icon(Icons.add),
                        label: Text('Agregar Cita'),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                        onPressed: () => mostrarFormularioCita(),
                      ),
                    ],
                  ),
                  SizedBox(height: 12),
                  TextField(
                    controller: searchController,
                    onChanged: filtrarCitas,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      labelText: 'Buscar cita',
                      border: OutlineInputBorder(),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                  SizedBox(height: 16),
                  Card(
                    color: Colors.white,
                    elevation: 2,
                    child: Padding(
                      padding: EdgeInsets.all(12),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: DataTable(
                          columns: const [
                            DataColumn(label: Text('Número')),
                            DataColumn(label: Text('Fecha')),
                            DataColumn(label: Text('Hora')),
                            DataColumn(label: Text('Cédula')),
                            DataColumn(label: Text('Nombre')),
                            DataColumn(label: Text('Apellido')),
                            DataColumn(label: Text('Tipo')),
                            DataColumn(label: Text('Estado')),
                            DataColumn(label: Text('Observaciones')),
                            DataColumn(label: Text('Acciones')),
                          ],
                          rows: citasFiltradas.map((c) {
                            return DataRow(cells: [
                              DataCell(Text(c.numeroCita)),
                              DataCell(Text(df.format(c.fechaCita))),
                              DataCell(Text(c.hora)),
                              DataCell(Text(c.cedulaPaciente)),
                              DataCell(Text(c.nombrePaciente)),
                              DataCell(Text(c.apellidoPaciente)),
                              DataCell(Text(c.tipoCita)),
                              DataCell(Text(c.estado)),
                              DataCell(Text(c.observaciones)),
                              DataCell(Row(
                                children: [
                                  IconButton(
                                    icon: Icon(Icons.edit, color: Colors.orange),
                                    onPressed: () => mostrarFormularioCita(cita: c),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.delete, color: Colors.red),
                                    onPressed: () {
                                      DataService.deleteAppointment(c.numeroCita);
                                      setState(() => citasFiltradas = DataService.citas);
                                    },
                                  ),
                                ],
                              )),
                            ]);
                          }).toList(),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}


