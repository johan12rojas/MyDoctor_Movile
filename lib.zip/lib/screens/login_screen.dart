import 'package:flutter/material.dart';
import '../services/data_service.dart';
import '../models/user_model.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // Controladores para los campos del login
  final _loginEmailController = TextEditingController();
  final _loginPasswordController = TextEditingController();

  // Controladores para los campos del registro
  final _regCedulaController = TextEditingController();
  final _regNombreController = TextEditingController();
  final _regApellidoController = TextEditingController();
  final _regEmailController = TextEditingController();
  final _regFechaNacimientoController = TextEditingController();
  final _regEspecializacionController = TextEditingController();
  final _regTelefonoController = TextEditingController();
  final _regPasswordController = TextEditingController();

  // Variable para alternar entre login y registro
  bool mostrarRegistro = false;

  // Método para mostrar mensajes en pantalla
  void _showSnackBar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  //funcion para que sirva el hp login
  void _login() {
    final email = _loginEmailController.text.trim();
    final password = _loginPasswordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      _showSnackBar('Por favor llena todos los campos');
      return;}

    final user = DataService.login(email, password);

    if (user != null) {
      _showSnackBar('Inicio de sesión exitoso');
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => HomeScreen()),
      );
    } else {
      _showSnackBar('Correo o contraseña incorrectos');
    }
  }

  //funcion registro
  void _register() {
    final cedula = _regCedulaController.text.trim();
    final nombre = _regNombreController.text.trim();
    final apellido = _regApellidoController.text.trim();
    final email = _regEmailController.text.trim();
    final fechaTexto = _regFechaNacimientoController.text.trim();
    final especializacion = _regEspecializacionController.text.trim();
    final telefono = _regTelefonoController.text.trim();
    final password = _regPasswordController.text.trim();

    if ([cedula, nombre, apellido, email, fechaTexto, especializacion, telefono, password].any((e) => e.isEmpty)) {
      _showSnackBar('Por favor complete todos los campos');
      return;
    }

    DateTime? fechaNacimiento;
    try {
      fechaNacimiento = DateTime.parse(fechaTexto);
    } catch (e) {
      _showSnackBar('Formato de fecha inválido (usa AAAA-MM-DD)');
      return;
    }

    final exists = DataService.usuarios.any((u) => u.email == email);
    if (exists) {
      _showSnackBar('Ya existe un usuario con ese correo');
      return;
    }

    final nuevoUsuario = UserModel(
      cedula: cedula,
      nombre: nombre,
      apellido: apellido,
      email: email,
      fechaNacimiento: fechaNacimiento,
      especializacion: especializacion,
      telefono: telefono,
      password: password,
    );

    DataService.usuarios.add(nuevoUsuario);

    _showSnackBar('Usuario registrado correctamente');
    setState(() {
      mostrarRegistro = false; // vuelve al login después del registro
    });
  }

  //aqui empezare el interfaz principal
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        //esto es para desplazarse
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            child: mostrarRegistro ? _buildRegisterForm() : _buildLoginForm(),
          ),
        ),
      ),
    );
  }

  // formulario para el login
Widget _buildLoginForm(){
  return Container(
    key: const ValueKey('login'),
    width: 320, //laura este es el tamaño NO LO TOQUEEE
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text(
          "My Doctor App",
          style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.blue ),
        ),
        const SizedBox(height: 40,),

        //aqui es para el correo
        TextField(
          controller: _loginEmailController,
          decoration: InputDecoration(
            labelText: 'Correo electrónico',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(9)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
          ),
        ),
        const SizedBox(height: 20),

        //campo para la contraseña
        TextField(
          controller: _loginPasswordController,
          obscureText: true,
          decoration: InputDecoration(
            labelText: 'contraseña',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(9)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12)
          ),
        ),

        const SizedBox(height: 20), //btn inicio de sesion BAJARLOA

        //btn para iniciar sesion
       SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _login,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Iniciar Sesión'),
            ),
          ),

          const SizedBox(height: 10),

          //btn para el registro
          TextButton(
            onPressed: () => setState(() => mostrarRegistro = true),
            child: const Text('¿No tienes cuenta? Regístrate aquí'),
          ),

      ] //cierre de children
    ),
  );
}
  

  //formulario para el registro
  Widget _buildRegisterForm() {
    return Column(
      key: const ValueKey('register'),
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text(
          "Registro de usuario",
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.blue),
        ),
        const SizedBox(height: 20),

        TextField(controller: _regCedulaController, decoration: const InputDecoration(labelText: 'Cédula')),
        TextField(controller: _regNombreController, decoration: const InputDecoration(labelText: 'Nombre')),
        TextField(controller: _regApellidoController, decoration: const InputDecoration(labelText: 'Apellido')),
        TextField(controller: _regTelefonoController, decoration: const InputDecoration(labelText: 'Teléfono')),
        TextField(controller: _regEmailController, decoration: const InputDecoration(labelText: 'Correo electrónico')),
        TextField(controller: _regFechaNacimientoController, decoration: const InputDecoration(labelText: 'Fecha de nacimiento (AAAA-MM-DD)')),
        TextField(controller: _regEspecializacionController, decoration: const InputDecoration(labelText: 'Especialización')),
        TextField(controller: _regPasswordController, decoration: const InputDecoration(labelText: 'Contraseña'), obscureText: true),

        const SizedBox(height: 25),

        ElevatedButton(
          onPressed: _register,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue,
            padding: const EdgeInsets.symmetric(horizontal: 60, vertical: 15),
          ),
          child: const Text('Registrar'),
        ),

        const SizedBox(height: 10),

        //boton para volver al login
        TextButton(
          onPressed: () {
            setState(() {
              mostrarRegistro = false;
            });
          },
          child: const Text('¿Ya tienes cuenta? Inicia sesión aquí'),
        ),
      ],
    );
  }
}
