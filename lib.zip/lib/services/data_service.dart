
//importamos los modelos de usuario y paciente que definen la estructura de esos datos
import '../models/user_model.dart';
import '../models/patient_model.dart';
import '../models/appointment_model.dart';
            


//esta clase es como una base de datos provisional en memoria
//aquí se guardan temporalmente los usuarios y pacientes mientras la app esta abierta
class DataService {

  //estas listas son privadas
  //lista de usuarios registrados doctores
  static final List<UserModel> _usuarios = [];

  //lista de pacientes registrados
  static final List<PatientModel> _pacientes = [];

  //lista de usuario doctor logueado actualmente
  static UserModel? _usuarioActual;


//metodos de usarios
  static void registerUser(UserModel user) {
    //verifica si ya existe un usuario con la misma cedula

    final existe = _usuarios.any((u) => u.cedula == user.cedula);

    //si no existe lo agrega a la lista
    if (!existe) {
      _usuarios.add(user);
    }
  }


//METODO INICIO SESION
 //busca un usuario que tenga el mismo correo y contraseña
  static UserModel? login(String email, String password) {
    try {

      //busca en la lista el primer usuario que coincida con el email y la contraseña
      final user = _usuarios.firstWhere(
        (u) => u.email == email && u.password == password,
      );

      //si lo encuentra lo guarda como el usuario actualmente logueado
      _usuarioActual = user;
      return user; //lo devuelve
    } catch (e) {
      return null; //si no lo encuentra devuelve inicio fallido
    }
  }

 // get que devuelve el usuario actualmente logueado
  static UserModel? get usuarioActual => _usuarioActual;


//METODO PACIENTES
  static void logout() {

    //borra el usuario actual y lo deja nulo
    _usuarioActual = null;
  }

//get que devuelve la lista completa de usuarios registrados
  static List<UserModel> get usuarios => _usuarios;


//METODOS DE PACIENTES
//metodo para agrgar un nuevo paciente
  static void addPatient(PatientModel patient) {

    //mira si la cedula ya esta en uso
    final existe = _pacientes.any((p) => p.cedula == patient.cedula);

    //si no existe lo agrega a la lista
    if (!existe) {
      _pacientes.add(patient);
    }
  }


//METODO PARA ELIMINAR UN PACIENTE POR CC
  static void removePatient(String cedula) {
    //busca en la lista y elimina a los pacientes que tengan esa cc
    _pacientes.removeWhere((p) => p.cedula == cedula);
  }


//METODO ACTUALIZAR LA INF DE UN PACIENTE EXISTENTE
  static void updatePatient(PatientModel updated) {

    //busca el indice del paciente en la lista segun su cedula
    final index = _pacientes.indexWhere((p) => p.cedula == updated.cedula);

    //si lo encuentra indice diferente de -1 reemplaza sus datos
    if (index != -1) {
      _pacientes[index] = updated;
    }
  }

//get que devuelve la lista completa de pacientes registrados
  static List<PatientModel> get patients => _pacientes;

//metodo alternativo para eliminar un paciente igual que removepatient
  static void deletePatient(String cedula) {
    _pacientes.removeWhere((p) => p.cedula == cedula);
  }

//bas de datos provicional
  static void initSampleData() {
    if (_usuarios.isEmpty) {
      _usuarios.add(
        UserModel(
          cedula: '123456789',
          nombre: 'Laura',
          apellido: 'Gomez',
          telefono: '3135463053',
          email: 'll',
          fechaNacimiento: DateTime(2006, 9, 5),
          especializacion: 'Medicina General',
          password: '1',
        ),
      );
    }

    if (_pacientes.isEmpty) {
      _pacientes.addAll([
        PatientModel(
          cedula: '1001',
          nombre: 'juliana',
          apellido: 'amaya',
          telefono: '3105557890',
          email: 'juli@gmail.com',
          fechaNacimiento: DateTime(2005, 4, 10),
          motivoConsulta: 'Dolor de cabeza recurrente',
        ),
        PatientModel(
          cedula: '1002',
          nombre: 'Melany',
          apellido: 'sepulveda',
          telefono: '3152223344',
          email: 'melany@gmail.com',
          fechaNacimiento: DateTime(2006, 4, 15),
          motivoConsulta: 'Chequeo general',
        ),
      ]);
    }
  }

 static List<PatientModel> pacientes = [];

  // lista de citas registradas
 static final List<AppointmentModel> _citas = [];

// btener todas las citas
 static List<AppointmentModel> get citas => _citas;

// 🔹 Agregar una nueva cita
 static void addAppointment(AppointmentModel appointment) {
   final existe = _citas.any((c) => c.numeroCita == appointment.numeroCita);
   if (!existe) {
    _citas.add(appointment);
  }
}

// eliminar cita por número
 static void deleteAppointment(String numeroCita) {
   _citas.removeWhere((c) => c.numeroCita == numeroCita);
}

//actualizar una cita existente
 static void updateAppointment(AppointmentModel updated) {
   final index = _citas.indexWhere((c) => c.numeroCita == updated.numeroCita);
   if (index != -1) {
     _citas[index] = updated;
  }
}

}

 