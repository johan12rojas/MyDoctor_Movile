import 'package:flutter/material.dart';
import '../screens/home_screen.dart';
import '../screens/citas_screen.dart';
import '../services/data_service.dart';
import '../models/user_model.dart';
import '../screens/login_screen.dart';
import '../screens/pagos_screen.dart'; // 👈 nuevo import

class SidebarMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final usuario = DataService.usuarioActual; // usuario logueado

    return Drawer(
      child: ListView(
        padding: const EdgeInsets.symmetric(vertical: 20),
        children: [
          // Encabezado con el nombre del doctor
          Container(
            color: Colors.blue,
            padding: const EdgeInsets.all(20),
            child: Center(
              child: Text(
                usuario != null
                    ? 'Dr. ${usuario.nombre} ${usuario.apellido}'
                    : 'Sin usuario',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),

          // Botón Home
          ListTile(
            leading: const Icon(Icons.home),
            title: const Text('Home'),
            onTap: () {
              Navigator.pop(context);
              _mostrarDatosUsuario(context, usuario);
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => HomeScreen()),
              );
            },
          ),

          // Botón Citas
          ListTile(
            leading: const Icon(Icons.calendar_today),
            title: const Text('Citas'),
            onTap: () {
              Navigator.pop(context);
              _mostrarDatosUsuario(context, usuario);
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => CitasScreen()),
              );
            },
          ),

          // btn pagos
          ListTile(
            leading: const Icon(Icons.payment),
            title: const Text('Pagos'),
            onTap: () {
              Navigator.pop(context);
              _mostrarDatosUsuario(context, usuario);
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => PagosScreen()),
              );
            },
          ),

          const Divider(),

          // Cerrar sesión
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Cerrar sesión'),
            onTap: () {
              Navigator.pop(context);
              DataService.logout();

              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (context) => LoginScreen()),
                (Route<dynamic> route) => false,
              );
            },
          ),
        ],
      ),
    );
  }

  // Diálogo con los datos del usuario
  void _mostrarDatosUsuario(BuildContext context, UserModel? usuario) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Datos del usuario'),
        content: usuario != null
            ? Text(
                'Nombre: ${usuario.nombre} ${usuario.apellido}\n'
                'Correo: ${usuario.email}\n'
                'Cédula: ${usuario.cedula}\n'
                'Especialización: ${usuario.especializacion}\n'
                'Fecha de nacimiento: '
                '${usuario.fechaNacimiento.day}/${usuario.fechaNacimiento.month}/${usuario.fechaNacimiento.year}',
              )
            : const Text('No hay usuario logueado.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }
}

