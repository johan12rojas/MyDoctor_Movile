//componentes visuales de flutter
import 'package:flutter/material.dart';

//para formatear fechas
import 'package:intl/intl.dart';

//modelo del paciente
import '../models/patient_model.dart';

//servicio que maneja los datos del paciente
import '../services/data_service.dart';

//widget principal

// este widget muestra un formulario emergente
// para agregar o editar la informacion de un paciente
class PatientFormDialog extends StatefulWidget {

  // si recibe un paciente el formulario sera para editarlo
  // si no recibe ninguno sera para crear uno nuevo
  final PatientModel? patient;
  PatientFormDialog({this.patient});

  @override
  State<PatientFormDialog> createState() => _PatientFormDialogState();
}

//estado del formulario
class _PatientFormDialogState extends State<PatientFormDialog> {

  // controladores de texto para capturar lo que escribe el usuario
  final cedula = TextEditingController();
  final nombre = TextEditingController();
  final apellido = TextEditingController();
  final telefono = TextEditingController();
  final email = TextEditingController();
  final motivo = TextEditingController();
  final entidad = TextEditingController();       // nuevo campo
  final procedimiento = TextEditingController(); // nuevo campo
  DateTime? fecha; //fecha de nacimiento del paciente

  // metodo inistate
  // se ejecuta una sola vez cuando se abre el formulario
  // si el paciente ya existe se llenan los campos con sus datos
  @override
  void initState() {
    super.initState();
    if (widget.patient != null) {
      cedula.text = widget.patient!.cedula;
      nombre.text = widget.patient!.nombre;
      apellido.text = widget.patient!.apellido;
      telefono.text = widget.patient!.telefono;
      email.text = widget.patient!.email;
      fecha = widget.patient!.fechaNacimiento;
      motivo.text = widget.patient!.motivoConsulta;
      entidad.text = widget.patient!.entidad ?? '';
      procedimiento.text = widget.patient!.procedimiento ?? '';
    }
  }

  @override
  void dispose() {
    cedula.dispose();
    nombre.dispose();
    apellido.dispose();
    telefono.dispose();
    email.dispose();
    motivo.dispose();
    entidad.dispose();
    procedimiento.dispose();
    super.dispose();
  }

  //interfaz visual
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      //titulo del formulario
      title: Text(widget.patient == null ? 'Agregar Paciente' : 'Editar Paciente'),

      //contenido del formulario
      content: SingleChildScrollView(
        child: Column(
          children: [

            // campo de cédula (ahora visible siempre)
            TextField(
              controller: cedula,
              decoration: InputDecoration(labelText: 'Cédula'),
              keyboardType: TextInputType.number,
            ),

            // campos de texto para el resto de datos
            TextField(controller: nombre, decoration: InputDecoration(labelText: 'Nombre')),
            TextField(controller: apellido, decoration: InputDecoration(labelText: 'Apellido')),
            TextField(controller: telefono, decoration: InputDecoration(labelText: 'Teléfono')),
            TextField(controller: email, decoration: InputDecoration(labelText: 'Correo electrónico')),

            SizedBox(height: 8),

            // boton para seleccionar la fecha de nacimiento
            ElevatedButton(
              onPressed: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: fecha ?? DateTime(1990),
                  firstDate: DateTime(1900),
                  lastDate: DateTime.now(),
                );
                if (picked != null) setState(() => fecha = picked);
              },

              // muestra la fecha elegida o el texto por defecto
              child: Text(
                fecha == null
                    ? 'Seleccionar fecha de nacimiento'
                    : 'Fecha: ${DateFormat('yyyy-MM-dd').format(fecha!)}',
              ),
            ),

            // campo para escribir el motivo de consulta
            TextField(controller: motivo, decoration: InputDecoration(labelText: 'Motivo de consulta')),

            SizedBox(height: 8),

            // nuevos campos entidad y procedimiento (obligatorios)
            TextField(
              controller: entidad,
              decoration: InputDecoration(labelText: 'Entidad *'),
            ),
            SizedBox(height: 8),
            TextField(
              controller: procedimiento,
              decoration: InputDecoration(labelText: 'Procedimiento *'),
            ),

            SizedBox(height: 8),
            Text(
              '* campos obligatorios',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),

      //botones para el formulario
      actions: [
        //boton para cerrar el formulario sin guardar
        TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancelar')),

        // Botón para guardar el paciente
        ElevatedButton(
          onPressed: () {
            //verifica que todos los campos esten completos
            if (cedula.text.isEmpty ||
                nombre.text.isEmpty ||
                apellido.text.isEmpty ||
                telefono.text.isEmpty ||
                email.text.isEmpty ||
                fecha == null ||
                entidad.text.isEmpty ||
                procedimiento.text.isEmpty) {
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text('Completa todos los campos requeridos')));
              return;
            }

            if (widget.patient == null) {
              // nuevo paciente
              final newPatient = PatientModel(
                cedula: cedula.text.trim(),
                nombre: nombre.text.trim(),
                apellido: apellido.text.trim(),
                telefono: telefono.text.trim(),
                email: email.text.trim(),
                fechaNacimiento: fecha!,
                motivoConsulta: motivo.text.trim(),
                entidad: entidad.text.trim(),
                procedimiento: procedimiento.text.trim(),
                fechaAtencion: null, // se asigna en módulo citas
                estadoPago: 'Pendiente', // se gestiona en módulo pagos
              );
              DataService.addPatient(newPatient);
            } else {
              // editar paciente existente
              final updatedPatient = PatientModel(
                cedula: cedula.text.trim(),
                nombre: nombre.text.trim(),
                apellido: apellido.text.trim(),
                telefono: telefono.text.trim(),
                email: email.text.trim(),
                fechaNacimiento: fecha!,
                motivoConsulta: motivo.text.trim(),
                entidad: entidad.text.trim(),
                procedimiento: procedimiento.text.trim(),
                fechaAtencion: widget.patient!.fechaAtencion,
                estadoPago: widget.patient!.estadoPago,
              );
              DataService.updatePatient(updatedPatient);
            }

            Navigator.pop(context, true);
          },
          child: Text('Guardar'),
        ),
      ],
    );
  }

  
}

