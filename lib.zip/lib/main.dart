//biblioteca para interfaces graficas
import 'package:flutter/material.dart';

// importa la pantalla de inicio de sesion desde la carpeta screen
import 'screens/login_screen.dart';

// importa el servicio que maneja los datos de los usuarios pacientes
import 'services/data_service.dart';

//funcion principal 

void main() {  //primera funcion que se va a ejecutar

// Llama a un método(todavia no esta definido) para empezar datos de ejemplo.
  // contiene informacion al inicializar el programa
  DataService.initSampleData();
  runApp(MyDoctorApp()); // ejecuta la aplicacion principal
}


//CLASE PRINCIPAL DE LA APLICACION

// MyDoctorApp es la clase raíz de la app, extiende StatelessWidget porque
// es una estructura fija
class MyDoctorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) { // build() construye la interfaz principal
    return MaterialApp(
      title: 'My Doctor App', //ovbiamente el titulo de la app
      theme: ThemeData(   // tema general de la aplicacion
        primarySwatch: Colors.blue,
      ),
      home: LoginScreen(), //indica la primera pantalla que debe aparecer
      debugShowCheckedModeBanner: false, //elimina un letrero que me estaba apareciendo
    );
  }
}
